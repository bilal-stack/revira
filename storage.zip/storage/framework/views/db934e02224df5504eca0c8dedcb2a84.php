



<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Orders</h4>
                            


                            <div class="table-responsive pt-3">
                                
                                <table id="orders" class="table table-bordered"> 
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Order Date</th>
                                            <th>Customer Name</th>
                                            <th>Customer Email</th>
                                            <th>Ordered Products</th>
                                            <th>Order Amount</th>
                                            <th>Order Status</th>
                                            <th>Payment Method</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            // dd($orders); // check if the authenticated/logged-in user is 'vendor' (show ONLY orders of products belonging to them), or 'admin' (show ALL orders)
                                        ?>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($order['orders_products']): ?> 
                                                <tr>
                                                    <td><?php echo e($order['id']); ?></td>
                                                    <td><?php echo e(date('Y-m-d h:i:s', strtotime($order['created_at']))); ?></td>
                                                    <td><?php echo e($order['name']); ?></td>
                                                    <td><?php echo e($order['email']); ?></td>
                                                    <td>
                                                        <?php $__currentLoopData = $order['orders_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($product['product_code']); ?> (<?php echo e($product['product_qty']); ?>)
                                                            <br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td><?php echo e($order['grand_total']); ?></td>
                                                    <td><?php echo e($order['order_status']); ?></td>
                                                    <td><?php echo e($order['payment_method']); ?></td>
                                                    <td>
                                                        <a title="View Order Details" href="<?php echo e(url('admin/orders/' . $order['id'])); ?>">
                                                            <i style="font-size: 25px" class="mdi mdi-file-document"></i> 
                                                        </a>
                                                        &nbsp;&nbsp;

                                                         
                                                        <a title="View Order Invoice" href="<?php echo e(url('admin/orders/invoice/' . $order['id'])); ?>" target="_blank">
                                                            <i style="font-size: 25px" class="mdi mdi-printer"></i> 
                                                        </a>
                                                        &nbsp;&nbsp;

                                                         
                                                        <a title="Print PDF Invoice" href="<?php echo e(url('admin/orders/invoice/pdf/' . $order['id'])); ?>" target="_blank">
                                                            <i style="font-size: 25px" class="mdi mdi-file-pdf"></i> 
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2022. All rights reserved.</span>
            </div>
        </footer>
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/admin/orders/orders.blade.php ENDPATH**/ ?>