


    <!-- Form-Fields /- -->
    <h4 class="section-h4 deliveryText mb-4">Add New Delivery Address</h4> 
    <div class="u-s-m-b-24">
        <input type="checkbox" class="check-box" id="ship-to-different-address" data-toggle="collapse" data-target="#showdifferent">

        <?php if(count($deliveryAddresses) > 0): ?>  
            <label class="label-text newAddress" for="ship-to-different-address">Ship to a different address?</label>
        <?php else: ?> 
            <label class="label-text newAddress" for="ship-to-different-address">Check to add Delivery Address</label>
        <?php endif; ?>

    </div>
    <div class="collapse mt-4" id="showdifferent">
        <!-- Form-Fields -->
         
        <form id="addressAddEditForm" action="javascript:;" method="post">
            <?php echo csrf_field(); ?>


            <input type="hidden" name="delivery_id"> 
            <div class="col-lg-12">
                <div class="form-group">
                    <input class="form-control font-sm" type="text" placeholder="Name*"
                           id="delivery_name" name="delivery_name" value="<?php echo e(old('delivery_name', '')); ?>">
                    <p id="delivery-delivery_name"></p>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="form-group">
                    <textarea class="form-control font-sm" type="text" placeholder="Address 1*"
                              id="delivery_address" name="delivery_address"><?php echo e(old('delivery_address')); ?></textarea>
                    <p id="delivery-delivery_address"></p>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <input class="form-control font-sm" type="text" placeholder="City*"
                           id="delivery_city" name="delivery_city" value="<?php echo e(old('delivery_city')); ?>">
                    <p id="delivery-delivery_city"></p>
                </div>
                <div class="form-group">
                    <input class="form-control font-sm" type="text" placeholder="State*"
                           id="delivery_state" name="delivery_state" value="<?php echo e(old('delivery_state')); ?>">
                    <p id="delivery-delivery_state"></p>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <select class="form-control font-sm select-style1 color-gray-700" id="delivery_country" name="delivery_country">
                        <option value="">Select Country</option>

                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($country['country_name']); ?>"  <?php if($country['country_name'] == \Illuminate\Support\Facades\Auth::user()->country): ?> selected <?php endif; ?>><?php echo e($country['country_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p id="delivery-delivery_country"></p>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <input class="form-control font-sm" type="text" placeholder="PostCode / ZIP*"
                           id="delivery_pincode" name="delivery_pincode" value="<?php echo e(old('delivery_pincode', '')); ?>">
                    <p id="delivery-delivery_pincode"></p>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <input class="form-control font-sm" type="text" placeholder="Mobile/Phone"
                           id="delivery_mobile" name="delivery_mobile" value="<?php echo e(old('delivery_mobile', '')); ?>">
                    <p id="delivery-delivery_mobile"></p>
                </div>
            </div>
            <div class="u-s-m-b-13">
                <button style="width: 100%" type="submit" class="btn btn-buy">Save</button> 
            </div>
        </form>
        <!-- Form-Fields /- -->
    </div>

<?php /**PATH C:\xampp\htdocs\revira\resources\views/front/products/delivery_addresses.blade.php ENDPATH**/ ?>