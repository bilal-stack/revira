



<?php $__env->startSection('content'); ?>
    <div class="section-box">
        <div class="breadcrumbs-div mb-0">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a class="font-xs color-gray-1000" href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a class="font-xs color-gray-500" href="#">Contact</a></li>
                </ul>
            </div>
        </div>
    </div>

    <section class="section-box shop-template mt-0">
        <div class="container">
            <div class="box-contact">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="contact-form">
                            <h3 class="color-brand-3 mt-60">Contact Us</h3>
                            <p class="font-sm color-gray-700 mb-30">Our team would love to hear from you!</p>

                            <?php if(Session::has('error_message')): ?>
                                <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <?php
                                        echo implode('', $errors->all('<div>:message</div>'));
                                    ?>

                                </div>
                            <?php endif; ?>
                            <form action="<?php echo e(url('contact')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group">
                                            <input class="form-control" type="text" placeholder="First name"
                                                name="name" value="<?php echo e(old('name')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group">
                                            <input class="form-control" type="text" placeholder="Last name">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <input class="form-control" type="email" placeholder="Email" name="email"
                                                value="<?php echo e(old('email')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <input class="form-control" type="tel" placeholder="Phone number">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <textarea class="form-control" placeholder="Message" rows="5" name="message"><?php echo e(old('message')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <input class="btn btn-buy w-auto" type="submit" value="Send message">
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="map">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d325467.51371614134!2d-73.98947743776016!3d40.72209526768085!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m3!3e0!4m0!4m0!5e0!3m2!1svi!2s!4v1664373110059!5m2!1svi!2s"
                                height="550" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>




























































        </div>
        <div class="box-contact-support pt-80 pb-50 background-gray-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 mb-30 text-center text-lg-start">
                        <h3 class="mb-5">We‘d love to here from you</h3>
                        <p class="font-sm color-gray-700">Chat with our friendly team</p>
                    </div>
                    <div class="col-lg-3 text-center mb-30">
                        <div class="box-image mb-20"><img src="assets/imgs/page/contact/chat.svg" alt="Revira"></div>
                        <h4 class="mb-5">Chat to sales</h4>
                        <p class="font-sm color-gray-700 mb-5">Speak to our team.</p><a class="font-sm color-gray-900"
                            href="mailto:sales@Revira.com">sales@Revira.com</a>
                    </div>
                    <div class="col-lg-3 text-center mb-30">
                        <div class="box-image mb-20"><img src="assets/imgs/page/contact/call.svg" alt="Revira"></div>
                        <h4 class="mb-5">Call us</h4>
                        <p class="font-sm color-gray-700 mb-5">Mon-Fri from 8am to 5pm</p><a
                            class="font-sm color-gray-900" href="tel:+1(555)000-0000">+1(555)000-0000</a>
                    </div>
                    <div class="col-lg-3 text-center mb-30">
                        <div class="box-image mb-20"><img src="assets/imgs/page/contact/map.svg" alt="Revira"></div>
                        <h4 class="mb-5">Visit us</h4>
                        <p class="font-sm color-gray-700 mb-5">Visit our office</p><span
                            class="font-sm color-gray-900">205 North Michigan Avenue, Suite 810<br>Chicago, 60601,
                            USA</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/front/pages/contact.blade.php ENDPATH**/ ?>