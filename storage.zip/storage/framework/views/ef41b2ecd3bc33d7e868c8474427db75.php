
<?php $__env->startSection('content'); ?>
   <section class="section-box shop-template mt-60">
    <div class="container">
        <div class="row mb-100">
            <div class="col-lg-1"></div>
            <div class="col-lg-5">
                <h3>Member Login</h3>
                <p class="font-md color-gray-500">Welcome back!</p>

                <!-- Show Session Status -->
                <?php if(session('status')): ?>
                    <div class="alert alert-success mb-4 text-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <!-- Show Validation Errors -->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger mb-4 text-danger">
                        <ul class="mb-0 ps-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('guest.login')); ?>" class="form-register mt-30 mb-30">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="mb-5 font-sm color-gray-700">Email-test *</label>
                        <input class="form-control" type="email" name="email" :value="old('email')" required autofocus placeholder="you@example.com">
                    </div>
                    <div class="form-group">
                        <label class="mb-5 font-sm color-gray-700">Password *</label>
                        <input class="form-control" type="password" name="password" required autocomplete="current-password" placeholder="******************">
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="color-gray-500 font-xs">
                                    <input class="checkagree" type="checkbox" name="remember"> Remember me
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-6 text-end">
                            <div class="form-group">
                                <?php if(Route::has('password.request')): ?>
                                    <a class="font-xs color-gray-500" href="<?php echo e(route('password.request')); ?>">Forgot your password?</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="font-md-bold btn btn-buy">Log In</button>
                    </div>
                    <div class="mt-20">
                        <span class="font-xs color-gray-500 font-medium">Don't have an account?</span>
                        <a class="font-xs color-brand-3 font-medium" href="<?php echo e(route('register')); ?>">Sign Up</a>
                    </div>
                </form>
            </div>
            <div class="col-lg-5"></div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/auth/login.blade.php ENDPATH**/ ?>