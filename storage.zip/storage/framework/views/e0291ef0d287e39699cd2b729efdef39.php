
<?php $__env->startSection('content'); ?>
    <?php
        $currency = session('currency', 'GBP')
    ?>
    <div class="section-box">
        <div class="breadcrumbs-div">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a class="font-xs color-gray-1000" href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a class="font-xs color-gray-500" href="<?php echo e(url('shop')); ?>">Shop</a></li>
                    <li><a class="font-xs color-gray-500" href="#">Checkout</a></li>
                </ul>
            </div>
        </div>
    </div>
   <section class="section-box shop-template">
    <div class="container">
        
        <?php if(Session::has('error_message')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

            </div>
        <?php endif; ?>

            <div class="row">

                <div class="col-lg-6">
                    <div class="box-border">
                        <div class="row">
                            <div class="col-lg-12" id="deliveryAddresses"> 
                                <?php echo $__env->make('front.products.delivery_addresses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <form name="checkoutForm" id="checkoutForm" action="<?php echo e(url('/checkout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <?php if(count($deliveryAddresses) > 0): ?>  

                                <h4 class="section-h4 mt-4 mb-4">Delivery Addresses</h4>

                                <?php $__currentLoopData = $deliveryAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="control-group" style="float: left; margin-right: 5px">
                                        
                                        <input type="radio" id="address<?php echo e($address['id']); ?>" name="address_id" value="<?php echo e($address['id']); ?>" shipping_charges="<?php echo e($address['shipping_charges']); ?>" total_price="<?php echo e($total_price); ?>" coupon_amount="<?php echo e(\Illuminate\Support\Facades\Session::get('couponAmount')); ?>" codpincodeCount="<?php echo e($address['codpincodeCount']); ?>" prepaidpincodeCount="<?php echo e($address['prepaidpincodeCount']); ?>">  
                                    </div>
                                    <div>
                                        <label class="control-label" for="address<?php echo e($address['id']); ?>">
                                            <?php echo e($address['name']); ?>, <?php echo e($address['address']); ?>, <?php echo e($address['city']); ?>, <?php echo e($address['state']); ?>, <?php echo e($address['country']); ?> (<?php echo e($address['mobile']); ?>)
                                        </label>
                                        <a href="javascript:;" data-addressid="<?php echo e($address['id']); ?>" class="removeAddress" style="float: right; margin-left: 10px">Remove</a>  
                                        <a href="javascript:;" data-addressid="<?php echo e($address['id']); ?>" class="editAddress"   style="float: right"                   >Edit</a>    
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-12 mt-4">
                                <div class="form-group mb-0">
                                    <textarea class="form-control font-sm" placeholder="Additional Information" rows="5" name="additional_info"><?php echo e(old('additional_info', '')); ?></textarea>
                                </div>

                                <div class="u-s-m-b-13 mt-4">
                                    <input type="checkbox" class="check-box" id="accept" name="accept" value="Yes" title="Please agree to T&C">
                                    <label class="label-text no-color" for="accept">I’ve read and accept the
                                        <a href="terms-and-conditions.html" class="u-c-brand">terms & conditions</a>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-20">
                        <div class="col-lg-6 col-5 mb-20">
                            <a class="btn font-sm-bold color-brand-1 arrow-back-1" href="<?php echo e(url('cart')); ?>">Return to Cart</a>
                        </div>
                        <div class="col-lg-6 col-7 mb-20 text-end">
                            <button type="submit" class="btn btn-buy w-auto arrow-next">Place an Order</button>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="box-border">
                        <h5 class="font-md-bold mb-20">Your Order</h5>
                        <div class="listCheckout">
                            <?php if(!empty($getCartItems) && count($getCartItems) > 0): ?>
                                <?php $__currentLoopData = $getCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $discountPriceData = \App\Models\Product::getDiscountAttributePrice($item['product_id'], $item['size']);
                                        $discountPrice = is_array($discountPriceData) ? ($discountPriceData['final_price'] ?? 0) : $discountPriceData;
                                    ?>
                                    <div class="item-wishlist">
                                        <div class="wishlist-product">
                                            <div class="product-wishlist">
                                                <div class="product-image">
                                                    <a href="<?php echo e(url('product/' . $item['product_id'])); ?>">
                                                        <img src="<?php echo e(asset('front/images/product_images/small/' . $item['product']['product_image'])); ?>"
                                                            alt="<?php echo e($item['product']['product_name']); ?>">
                                                    </a>
                                                </div>
                                                <div class="product-info">
                                                    <a href="<?php echo e(url('product/' . $item['product_id'])); ?>">
                                                        <h6 class="color-brand-3"><?php echo e($item['product']['product_name']); ?></h6>
                                                    </a>








                                                </div>
                                            </div>
                                        </div>
                                        <div class="wishlist-status">
                                            <h5 class="color-gray-500">x<?php echo e($item['quantity']); ?></h5>
                                        </div>
                                        <div class="wishlist-price">
                                            <h4 class="color-brand-3 font-lg-bold">
                                                <?php
                                                    $price = $discountPrice * $item['quantity'];
                                                    $price = currency($price, $from = null, $currency);
                                                ?>
                                                <?php echo e($price); ?>

                                            </h4>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>Your cart is empty.</p>
                            <?php endif; ?>
                        </div>

                        
                        <div class="coupon-code mt-20 mb-20">
                            <div class="input-group">
                                <input class="form-control font-sm" type="text" placeholder="Enter coupon code"
                                    name="coupon_code" value="<?php echo e(old('coupon_code')); ?>">
                                <button type="submit" name="apply_coupon" class="btn btn-buy w-auto arrow-next">Apply</button>
                            </div>
                            <?php if(session('couponError')): ?>
                                <p class="text-danger mt-1"><?php echo e(session('couponError')); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="box-total">
                            <div class="total-price d-flex justify-content-between">
                                <h5 class="color-brand-3">Subtotal</h5>
                                <h5 class="color-brand-3">
                                    <?php
                                        $price = currency($total_price, $from = null, $currency);
                                    ?>
                                   <?php echo e($price); ?>

                                </h5>
                            </div>
                            <div class="total-price d-flex justify-content-between">
                                <h5 class="color-brand-3">Shipping Charges</h5>
                                <h5 class="color-brand-3">
                                    <?php
                                        $price = currency($shipping_charges ?? 0, $from = null, $currency);
                                    ?>
                                    <?php echo e($price); ?>

                                </h5>
                            </div>
                            <?php if(session('couponAmount') && session('couponAmount') > 0): ?>
                                <div class="total-price d-flex justify-content-between">
                                    <h5 class="color-brand-3">Coupon Discount</h5>
                                    <h5 class="color-brand-3">
                                        <?php
                                            $price = currency(session('couponAmount'), $from = null, $currency);
                                        ?>
                                        -<?php echo e($price); ?>

                                    </h5>
                                </div>
                            <?php endif; ?>
                            <div class="total-price d-flex justify-content-between font-lg-bold">
                                <h5 class="color-brand-3">Total</h5>
                                <h5 class="color-brand-3">
                                    <?php
                                        $price = ($final_price ?? $total_price) + ($shipping_charges ?? 0) - (session('couponAmount') ?? 0);
                                        $price = currency($price, $from = null, $currency);
                                    ?>

                                    <?php echo e($price); ?>

                                </h5>
                            </div>
                        </div>

                        
                        <div class="payment-method mt-30">
                            <h5 class="font-md-bold color-brand-3 mb-20">Payment Methods</h5>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_gateway" id="paypal" value="Paypal"
                                    value="PayPal" <?php echo e(old('payment_method') == 'PayPal' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="paypal">PayPal</label>
                            </div>





                        </div>


                    </div>
                </div>
                </form>
            </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/front/products/checkout.blade.php ENDPATH**/ ?>