
<?php $__env->startSection('content'); ?>
    <div class="section-box">
        <div class="breadcrumbs-div">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a class="font-sm color-gray-1000" href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a class="font-sm color-gray-500" href="#">Vendors</a></li>
                </ul>
            </div>
        </div>
    </div>
    <section class="section-box shop-template mt-0">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-30">
                    <h3>Vendors</h3>


                </div>
                <div class="col-lg-6 mb-30 text-end">



                    <a class="btn btn-buy w-auto font-sm-bold" href="<?php echo e(url('vendor/login-register')); ?>">Open a Shop</a></div>
            </div>
            <div class="border-bottom pt-0 mb-30"></div>
            <div class="row">
                <div class="col-lg-12 order-first order-lg-last">

                    <div class="row">
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="row">
                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <div class="card-vendor">
                                            <div class="card-top-vendor">
                                                <div class="card-top-vendor-left">
                                                   <a href="<?php echo e(url($vendor->vendorbusinessdetails->shop_name. '/products')); ?>">
                                                       <?php if(!empty($vendor->vendorbusinessdetails->shop_image)): ?>
                                                           <img src="<?php echo e(url('admin/images/photos/' . $vendor->vendorbusinessdetails->shop_image)); ?>" alt="<?php echo e($vendor->vendorbusinessdetails->shop_name); ?>">
                                                       <?php else: ?>
                                                           <img src="<?php echo e(asset('front/images/store-default.png')); ?>" alt="<?php echo e($vendor->vendorbusinessdetails->shop_name); ?>">
                                                       <?php endif; ?>
                                                   </a>
                                                </div>
                                                <div class="card-top-vendor-right">
                                                    <a href="<?php echo e(url($vendor->vendorbusinessdetails->shop_name. '/products')); ?>">
                                                        <p class="font-lg-bold color-gray-500" style="color: #000000ad"><?php echo e($vendor->vendorbusinessdetails->shop_name); ?></p>
                                                    </a>

                                                    <p class="font-sm color-gray-500 mt-10">Member since <?php echo e(\Carbon\Carbon::parse($vendor->created_at)->format('F Y')); ?></p>
                                                    <a class="btn btn-gray mt-2" href="<?php echo e(url($vendor->vendorbusinessdetails->shop_name. '/products')); ?>">View Products</a>
                                                </div>
                                            </div>
                                            <div class="card-bottom-vendor">
                                                <p class="fontlg color-gray-500 location mb-10"><?php echo e($vendor->vendorbusinessdetails->shop_country); ?> </p>

                                                <p class="font-lg color-gray-500 phone">
                                                    <?php
                                                        $vendorId = userFromVendor( $vendor->id);
                                                    ?>
                                                    <a class="btn btn-gray" href="<?php echo e(url('chat/'. $vendorId)); ?>">Message</a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12">
                                        <div class="box-swiper">
                                            <div class="swiper-container swiper-vendor-list">
                                                <div class="swiper-wrapper mb-15">
                                                    <?php $__currentLoopData = $vendor->limitedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="swiper-slide">

                                                                <?php
                                                                    $product_image_path = 'front/images/product_images/small/' . $product['product_image'];
                                                                ?>
                                                                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                                                                    <div class="card-grid-style-2">
                                                                        <div class="image-box">
                                                                            <a href="<?php echo e(url('product/' . $product['id'])); ?>">
                                                                                <?php if(!empty($product['product_image']) && file_exists($product_image_path)): ?> 
                                                                                <img src="<?php echo e(asset($product_image_path)); ?>" alt="Product">
                                                                                <?php else: ?> 
                                                                                <img  src="<?php echo e(asset('front/images/product_images/small/no-image.png')); ?>" alt="Product">
                                                                                <?php endif; ?>

                                                                            </a>
                                                                        </div>
                                                                        <div class="info-right"><span class="font-xs color-gray-500"><?php echo e($product['brand']['name'] ?? $product['product_code']); ?></span>
                                                                            <br>
                                                                            <a class="color-brand-3 font-sm-bold" href="<?php echo e(url('product/' . $product['id'])); ?>"><?php echo e($product['product_name']); ?></a>
                                                                            <div class="rating">
                                                                                <?php
                                                                                    $avg = round($product['ratings_avg_rating'], 1); // average like 4.2
                                                                                    $fullStars = floor($avg); // e.g. 4
                                                                                    $halfStar = ($avg - $fullStars) >= 0.5;
                                                                                    $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
                                                                                ?>

                                                                                
                                                                                <?php for($i = 0; $i < $fullStars; $i++): ?>
                                                                                    <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star.svg')); ?>" alt="Revira">
                                                                                <?php endfor; ?>

                                                                                
                                                                                <?php if($halfStar): ?>
                                                                                    <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star-gray.svg')); ?>" alt="Revira">
                                                                                <?php endif; ?>
                                                                                
                                                                                <?php for($i = 0; $i < $emptyStars; $i++): ?>
                                                                                    <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star-gray.svg')); ?>" alt="Revira">
                                                                                <?php endfor; ?>

                                                                                <span class="font-xs color-gray-500">(<?php echo e(number_format($avg, 1)); ?>/5, <?php echo e($product['ratings_count']); ?> reviews</span>
                                                                            </div>
                                                                            <?php
                                                                                $getDiscountPrice = \App\Models\Product::getDiscountPrice($product['id']);
                                                                            ?>
                                                                            <?php echo $__env->make('front.layout.price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div class="swiper-pagination"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <nav>
                        <?php echo e($vendors->links()); ?>

                    </nav>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var swiper = new Swiper(".swiper-vendor-list", {
            slidesPerView: 3,
            spaceBetween: 20,
            pagination: {
                el: ".swiper-pagination",
                dynamicBullets: true,
            },
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/front/shop_vendor_list.blade.php ENDPATH**/ ?>