<!-- Row-of-Product-Container -->
<div class="row mt-20">
    <?php $__currentLoopData = $categoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 product-item">
            <?php
                $product_image_path = 'front/images/product_images/small/' . $product['product_image'];
            ?>

            <div class="card-grid-style-3">
                <div class="card-grid-inner">
                    <div class="tools">
                        <a class="btn btn-wishlist btn-tooltip mb-10" href="<?php echo e(url('wishlist/'. $product['id'])); ?>" aria-label="Add To Wishlist"></a>
                        
                    </div>
                    <div class="image-box">
                        <span class="label bg-brand-2">-% <?php echo e($product['product_discount']); ?></span>
                        <a href="<?php echo e(url('product/' . $product['id'])); ?>">
                            <?php if(!empty($product['product_image']) && file_exists($product_image_path)): ?> 
                            <img src="<?php echo e(asset($product_image_path)); ?>" alt="Product">
                            <?php else: ?> 
                            <img src="<?php echo e(asset('front/images/product_images/small/no-image.png')); ?>" alt="Product">
                            <?php endif; ?>
                        </a>
                    </div>
                    <div class="info-right"><span class="font-xs color-gray-500"><?php echo e($product['brand']['name'] ?? $product['product_code']); ?></span>
                        <br>
                        <a class="color-brand-3 font-sm-bold" href="<?php echo e(url('product/' . $product['id'])); ?>"><?php echo e($product['product_name']); ?></a>
                        <div class="rating">
                            <?php
                                $avg = round($product['ratings_avg_rating'], 1); // average like 4.2
                                $fullStars = floor($avg); // e.g. 4
                                $halfStar = ($avg - $fullStars) >= 0.5;
                                $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
                            ?>

                            
                            <?php for($i = 0; $i < $fullStars; $i++): ?>
                                <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star.svg')); ?>" alt="Revira">
                            <?php endfor; ?>

                            
                            <?php if($halfStar): ?>
                                <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star-gray.svg')); ?>" alt="Revira">
                            <?php endif; ?>
                            
                            <?php for($i = 0; $i < $emptyStars; $i++): ?>
                                <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star-gray.svg')); ?>" alt="Revira">
                            <?php endfor; ?>

                            <span class="font-xs color-gray-500">(<?php echo e(number_format($avg, 1)); ?>/5) <?php echo e($product['ratings_count']); ?> reviews</span>
                        </div>
                        <?php
                            $getDiscountPrice = \App\Models\Product::getDiscountPrice($product['id']);
                        ?>
                        <?php echo $__env->make('front.layout.price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <p class="list-features">
                            <?php echo e($product['description']); ?>

                        </p>
                        <div class="mt-20 box-add-cart"><a class="btn btn-cart" href="<?php echo e(url('product/' . $product['id'])); ?>">Add To Cart</a></div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php if(!isset($_REQUEST['search'])): ?>


    
    
    <?php if(isset($_GET['sort'])): ?> 
    <div>
        <?php echo e($categoryProducts->appends(['sort' => $_GET['sort']])->links()); ?>  
    </div>
    <?php else: ?>
        <div>
            <?php echo e($categoryProducts->links()); ?> 
        </div>
    <?php endif; ?>


<?php endif; ?>
<!-- Row-of-Product-Container /- -->
<?php /**PATH C:\xampp\htdocs\revira\resources\views/front/vendors/ajax_vendor_products_listing.blade.php ENDPATH**/ ?>