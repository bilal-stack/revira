

<?php $total_price = 0 ?>

<?php
    $getCartItems = getCartItems(); // getCartItems() function is in our custom Helpers/Helper.php file that we have registered in 'composer.json' file --}}
    $countCartItems = count($getCartItems);
?>


<div class="d-inline-block box-dropdown-cart"><span class="font-lg icon-list icon-cart"><span>Cart</span><span class="number-item font-xs"><?php echo e($countCartItems); ?></span></span>

    <div class="dropdown-cart">
        <?php $__currentLoopData = $getCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php
            $getDiscountAttributePrice = \App\Models\Product::getDiscountAttributePrice($item['product_id'], $item['size']);
            ?>
        <div class="item-cart mb-20">
            <div class="cart-image">
                <img src="<?php echo e(asset('front/images/product_images/small/' . $item['product']['product_image'])); ?>" alt="<?php echo e($item['product']['product_name']); ?>">
            </div>
            <div class="cart-info">
                <a class="font-sm-bold color-brand-3" href="s<?php echo e(url('product/' . $item['product_id'])); ?>"><?php echo e($item['product']['product_name']); ?></a>
                <p><span class="color-brand-2 font-sm-bold">
                        <?php
                            $currency = session('currency', 'GBP');
                            $price = currency($getDiscountAttributePrice['final_price'], $from = null, $currency);
                        ?>
                        <?php echo e($item['quantity']); ?> x <?php echo e($price); ?>

                    </span></p>
            </div>
        </div>
        
        <?php $total_price = $total_price + ($getDiscountAttributePrice['final_price'] * $item['quantity']) ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        <div class="border-bottom pt-0 mb-15"></div>
        <div class="cart-total">
            <div class="row">
                <div class="col-6 text-start"><span class="font-md-bold color-brand-3">Total</span></div>
                <div class="col-6"><span class="font-md-bold color-brand-1">
                        <?php
                            $currency = session('currency', 'GBP');
                            $price = currency($total_price, $from = null, $currency);
                        ?>
                        <?php echo e($price); ?>

                    </span></div>
            </div>
            <div class="row mt-15">
                <div class="col-6 text-start"><a class="btn btn-cart w-auto" href="<?php echo e(url('cart')); ?>">View cart</a></div>
                <div class="col-6"><a class="btn btn-buy w-auto" href="<?php echo e(url('checkout')); ?>">Checkout</a></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\revira\resources\views/front/layout/header_cart_items.blade.php ENDPATH**/ ?>