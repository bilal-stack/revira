<?php
$sections = \App\Models\Section::sections();
$categories = \App\Models\Category::with('subCategories')->where('parent_id', 0)->get();
?>
<style>
    .nav-link {
        display: block;
        padding: unset;
    }
    </style>

<div class="topbar">
    <div class="container-topbar">
        <div class="menu-topbar-left d-none d-xl-block">
            <ul class="nav-small">

                <li><a class="font-xs" href="<?php echo e(url('about-us')); ?>">About Us</a></li>
                <li><a class="font-xs" href="<?php echo e(url('vendor/login-register')); ?>">Open a shop</a></li>
            </ul>
        </div>
        <div class="info-topbar text-center d-none d-xl-block">
            <span class="font-xs color-brand-3">

            </span>
            <span class="font-sm-bold color-success">

            </span>
        </div>
        <div class="menu-topbar-right"><span class="font-xs color-brand-3">Need help? Call Us:</span><span
                class="font-sm-bold color-success"> + 1800 900</span>
            <div id="google_translate_element" style="display: none"></div>
            <div class="dropdown dropdown-language">
                <button class="btn dropdown-toggle" id="dropdownPage" type="button" data-bs-toggle="dropdown"
                        aria-expanded="true" data-bs-display="static">
        <span class="dropdown-right font-xs color-brand-3">
            <img src="<?php echo e(asset('front/new/assets/imgs/template/en.svg')); ?>" alt="Revira"> English
        </span>
                </button>

                <ul class="dropdown-menu dropdown-menu-light" aria-labelledby="dropdownPage" data-bs-popper="static">
                    <li>
                        <a class="dropdown-item" href="#" onclick="translateLanguage('en');return false;">
                            <img src="<?php echo e(asset('front/new/assets/imgs/template/flag-en.svg')); ?>" alt="Revira"> English
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#" onclick="translateLanguage('fr');return false;">
                            <img src="<?php echo e(asset('front/new/assets/imgs/template/flag-fr.svg')); ?>" alt="Revira"> Français
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#" onclick="translateLanguage('es');return false;">
                            <img src="<?php echo e(asset('front/new/assets/imgs/template/flag-es.svg')); ?>" alt="Revira"> Español
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#" onclick="translateLanguage('pt');return false;">
                            <img src="<?php echo e(asset('front/new/assets/imgs/template/flag-pt.svg')); ?>" alt="Revira"> Português
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#" onclick="translateLanguage('zh-CN');return false;">
                            <img src="<?php echo e(asset('front/new/assets/imgs/template/flag-cn.svg')); ?>" alt="Revira"> 中国人
                        </a>
                    </li>
                </ul>
            </div>

            <div class="dropdown dropdown-language">
                <button class="btn dropdown-toggle" id="dropdownPage2" type="button" data-bs-toggle="dropdown" aria-expanded="true" data-bs-display="static">
                    <span class="dropdown-right font-xs color-brand-3">
                        <?php echo e(strtoupper(session('currency', 'gbp'))); ?>

                    </span>
                </button>
                <ul class="dropdown-menu dropdown-menu-light dropdown-menu-end" aria-labelledby="dropdownPage2" data-bs-popper="static">
                    <?php
                        $selectedCurrency = session('currency', 'gbp');
                    ?>
                    <li><a class="dropdown-item <?php echo e($selectedCurrency == 'gbp' ? 'active' : ''); ?>" onclick="setCurrency('gbp');return false;" href="#">GBP</a></li>
                    <li><a class="dropdown-item <?php echo e($selectedCurrency == 'usd' ? 'active' : ''); ?>" onclick="setCurrency('usd');return false;" href="#">USD</a></li>
                    <li><a class="dropdown-item <?php echo e($selectedCurrency == 'eur' ? 'active' : ''); ?>" onclick="setCurrency('eur');return false;" href="#">EUR</a></li>
                    <li><a class="dropdown-item <?php echo e($selectedCurrency == 'aud' ? 'active' : ''); ?>" onclick="setCurrency('aud');return false;" href="#">AUD</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Header -->
<header class="header sticky-bar">
    <div class="container">
        <div class="main-header">
            <div class="header-left">
                <div class="header-logo"><a class="d-flex" href="<?php echo e(url('/')); ?>">
                        <img alt="Revira" src="<?php echo e(asset('front/new/assets/imgs/logo.png')); ?>">
                    </a>
                </div>
                <div class="header-nav">
                    <nav class="nav-main-menu d-none d-xl-block">
                        <ul class="main-menu">
                            <li><a href="<?php echo e(url('vendors/list')); ?>">Suppliers</a></li>
                            <li><a href="<?php echo e(url('shop')); ?>">Shop</a></li>

                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarBrandsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Brands
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarBrandsDropdown">
                                    <?php $__currentLoopData = $headerBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item" href="<?php echo e($brand['name']); ?>" onclick="window.location.href='<?php echo e(url('shop')); ?>'"><?php echo e($brand['name']); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>

                        </ul>
                    </nav>
                    <div class="burger-icon burger-icon-white"><span class="burger-icon-top"></span><span
                            class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
                </div>
                <div class="header-search">
                    <div class="box-header-search">
                        <form class="form-search" action="<?php echo e(url('/search-products')); ?>" method="get">
                            <div class="box-category">
                                <select class="select-active select2-hidden-accessible">
                                    <option>All categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category['id']); ?>"
                                            <?php if(isset($_REQUEST['category_id']) && !empty($_REQUEST['category_id']) && $_REQUEST['category_id'] == $category['id']): ?> selected <?php endif; ?>><?php echo e($category['category_name']); ?>

                                        </option>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="box-keysearch">
                                <input class="form-control font-xs" type="text" name="search"
                                    <?php if(isset($_REQUEST['search']) && !empty($_REQUEST['search'])): ?> value="<?php echo e($_REQUEST['search']); ?>" <?php endif; ?>
                                    placeholder="Search for items">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="header-nav">
                    <nav class="nav-main-menu d-none d-xl-block">
                        <ul class="main-menu">
                            <li><a class="active" href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(url('contact')); ?>">Contact Us</a></li>
                        </ul>
                    </nav>
                    <div class="burger-icon burger-icon-white"><span class="burger-icon-top"></span><span
                            class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
                </div>
                <div class="header-shop">
                    <div class="d-inline-block box-dropdown-cart">
                        <span class="font-lg icon-list icon-account"><span>Account</span></span>
                        <div class="dropdown-account">
                            <ul>
                                <?php if(!Auth::check()): ?>
                                    <li><a href="<?php echo e(url('login')); ?>">User Login</a></li>
                                    <li><a href="<?php echo e(url('user/login-register')); ?>">User Register</a></li>
                                    <li><a href="<?php echo e(url('vendor/login-register')); ?>">Vendor Login</a></li>
                                <?php else: ?>
                                    <li><a href="<?php echo e(url('user/account')); ?>">My Account</a></li>
                                    <li><a href="<?php echo e(url('user/orders')); ?>">My Orders</a></li>
                                    <li><a href="<?php echo e(route('user.logout')); ?>">Sign out</a></li>
                                <?php endif; ?>

                            </ul>
                        </div>
                    </div>

                    <?php echo $__env->make('front.layout.header_cart_items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>
        </div>
    </div>
</header>












































<div class="mobile-header-active mobile-header-wrapper-style perfect-scrollbar">
    <div class="mobile-header-wrapper-inner">
        <div class="mobile-header-content-area">
            <div class="mobile-logo"><a class="d-flex" href="<?php echo e(url('/')); ?>">
                    <img alt="Revira" src="<?php echo e(asset('front/new/assets/imgs/logo.png')); ?>"></a></div>
            <div class="perfect-scroll">
                <div class="mobile-menu-wrap mobile-header-border">
                    <nav class="mt-15">
                        <ul class="mobile-menu font-heading">
                            <li><a href="<?php echo e(url('shop')); ?>">Shop</a></li>
                            <li><a href="<?php echo e(url('vendors/list')); ?>">Vendors</a></li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Categories
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item" href="<?php echo e(url($category['url'])); ?>" onclick="window.location.href='<?php echo e(url($category['url'])); ?>'"><?php echo e($category['category_name']); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Brands
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php $__currentLoopData = $headerBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item" href="<?php echo e($brand['name']); ?>" onclick="window.location.href='<?php echo e(url('shop')); ?>'"><?php echo e($brand['name']); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="mobile-account" style="margin: unset; padding: unset; border: unset; border-bottom: thin solid #DDE4F0">
                    <?php if(Auth::check()): ?>
                        <div class="mobile-header-top">
                            <div class="user-account">
                                <a href="<?php echo e(url('user/account')); ?>">
                                    <img src="<?php echo e(url('admin/images/photos/no-image.gif')); ?>" alt="Revira">
                                </a>
                                <div class="content">
                                    <h6 class="user-name">Hello<span class="text-brand"> <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?> !</span></h6>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="site-copyright color-gray-400 mt-30">Copyright 2025 &copy; Revira.</div>
            </div>
        </div>
    </div>
</div>
<!-- Header /- -->
<?php /**PATH C:\xampp\htdocs\revira\resources\views/front/layout/header.blade.php ENDPATH**/ ?>