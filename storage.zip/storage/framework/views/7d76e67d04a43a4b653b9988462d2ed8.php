<?php
    $categories = \App\Models\Category::inRandomOrder()->get();
    $productFilters = \App\Models\ProductsFilter::productFilters(); // Get all the (enabled/active) Filters
?>

<div class="sidebar-border mb-0">
    <div class="sidebar-head">
        <h6 class="color-gray-900">Product Categories</h6>
    </div>
    <div class="sidebar-content">
        <ul class="list-nav-arrow">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(url($category->url)); ?>"><?php echo e($category['category_name']); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<div class="sidebar-border mb-40">
    <div class="sidebar-head">
        <h6 class="color-gray-900">Products Filter</h6>
    </div>
    <div class="sidebar-content">
        <?php
        if (isset($url) && !str_contains($url, 'shop')) {
            $getSizes = \App\Models\ProductsFilter::getSizes($url); // get product sizes depending on the URL (to show the proper relevant 'size' filter values (whether small, medium, ... OR 64GB-4GB, 128GB-6GB, ...))    // $url is passed from the Front/ProductsController.php
            $getColors = \App\Models\ProductsFilter::getColors($url); // get product colors depending on the URL (to show the proper relevant 'color' filter values (whether small, medium, ... OR 64GB-4GB, 128GB-6GB, ...))    // $url is passed from the Front/ProductsController.php
            $getBrands = \App\Models\ProductsFilter::getBrands($url); // get product brands depending on the URL (to show the proper relevant 'brand' filter values (whether LC Waikiki, Concrete, ... OR iPhone, Xiaomi, ...))    // $url is passed from the Front/ProductsController.php
            $prices = array('0-1000', '1000-2000', '2000-5000', '5000-10000', '10000-100000');
        } else {
            $getSizes = \App\Models\ProductsFilter::getSizesWithoutCat(); // get product sizes depending on the URL (to show the proper relevant 'size' filter values (whether small, medium, ... OR 64GB-4GB, 128GB-6GB, ...))    // $url is passed from the Front/ProductsController.php
            $getColors = \App\Models\ProductsFilter::getColorsWithoutCat(); // get product colors depending on the URL (to show the proper relevant 'color' filter values (whether small, medium, ... OR 64GB-4GB, 128GB-6GB, ...))    // $url is passed from the Front/ProductsController.php
            $getBrands = \App\Models\ProductsFilter::getBrandsWithoutCat(); // get product brands depending on the URL (to show the proper relevant 'brand' filter values (whether LC Waikiki, Concrete, ... OR iPhone, Xiaomi, ...))    // $url is passed from the Front/ProductsController.php
            $prices = array('0-1000', '1000-2000', '2000-5000', '5000-10000', '10000-100000');
        }

        ?>

        <h6 class="color-gray-900 mt-20 mb-10">Sizes</h6>
        <ul class="list-checkbox">
            <form class="facet-form" action="#" method="post">
                <?php $__currentLoopData = $getSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <label class="cb-container" for="size<?php echo e($key); ?>">
                            <input type="checkbox" class="check-box size" id="size<?php echo e($key); ?>" name="size[]"
                                   value="<?php echo e($size); ?>">
                            <span class="text-small"><?php echo e($size); ?></span>
                            <span class="checkmark"></span>
                        </label>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </ul>

        <h6 class="color-gray-900 mt-20 mb-10">Color</h6>
        <ul class="list-color">
            <?php $__currentLoopData = $getColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <label class="cb-container" for="color<?php echo e($key); ?>">
                        <input type="checkbox" class="check-box color" id="color<?php echo e($key); ?>" name="color[]"
                               value="<?php echo e($color); ?>">
                        <span class="text-small"><?php echo e($color); ?></span>
                        <span class="checkmark"></span>
                    </label>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

        <h6 class="color-gray-900 mt-20 mb-10">Brands</h6>
        <ul class="list-checkbox">
            <?php $__currentLoopData = $getBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <label class="cb-container" for="brand<?php echo e($key); ?>">
                        <input type="checkbox" class="check-box brand" id="brand<?php echo e($key); ?>" name="brand[]"
                               value="<?php echo e($brand['id']); ?>">   
                        <span class="text-small"><?php echo e($brand['name']); ?></span>
                        <span class="checkmark"></span>
                    </label>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

        <?php $__currentLoopData = $productFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php
                if (isset($categoryDetails['categoryDetails']['id'])){
                    $filterAvailable = \App\Models\ProductsFilter::filterAvailable($filter['id'], $categoryDetails['categoryDetails']['id']); // $categoryDetails was passed from the listing() method in the Front/ProductsController
                } else {
                    $filterAvailable = \App\Models\ProductsFilter::filterAvailableWithoutCat($filter['id']); // $categoryDetails was passed from the listing() method in the Front/ProductsController
                }
                    // Firstly, for every filter in the `products_filters` table, Get the filter's (from the foreach loop) `cat_ids` using filterAvailable() method, then check if the current category id (using the $categoryDetails variable and depending on the URL) exists in the filter's `cat_ids`. If it exists, then show the filter, if not, then don't show the filter
            ?>
            <?php if($filterAvailable == 'Yes' && count($filter['filter_values']) > 0): ?>
                <h6 class="color-gray-900 mt-20 mb-10 title-name"><?php echo e($filter['filter_name']); ?></h6>
                <ul class="list-checkbox">
                    <form class="facet-form" action="#" method="post">
                        <?php $__currentLoopData = $filter['filter_values']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <label class="cb-container" for="<?php echo e($value['filter_value']); ?>">
                                    <input type="checkbox" class="check-box <?php echo e($filter['filter_column']); ?>"
                                           id="<?php echo e($value['filter_value']); ?>" name="<?php echo e($filter['filter_column']); ?>[]"
                                           value="<?php echo e($value['filter_value']); ?>">   
                                    <span class="text-small"><?php echo e(ucwords($value['filter_value'])); ?></span>
                                    <span class="checkmark"></span>
                                </label>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>

                </ul>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h6 class="color-gray-900 mt-10 mb-10">Price</h6>
        <ul class="list-checkbox">
            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <label class="cb-container" for="price<?php echo e($key); ?>">
                        <input type="checkbox" class="check-box price" id="price<?php echo e($key); ?>" name="price[]"
                               value="<?php echo e($price); ?>">   
                        <span class="text-small"><?php echo e($price); ?></span>
                        <span class="checkmark"></span>
                    </label>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\revira\resources\views/front/vendors/filters.blade.php ENDPATH**/ ?>