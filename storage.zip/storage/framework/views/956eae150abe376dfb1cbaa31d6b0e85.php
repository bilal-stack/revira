 


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <tr><td>Dear <?php echo e($name); ?>!</td></tr>
        <tr><td>&nbsp;<br></td></tr>
        <tr><td>Please click on the link below to confirm your Vendor Account :-</td></tr>
        <tr><td><a href="<?php echo e(url('vendor/confirm/' . $code)); ?>"><?php echo e(url('vendor/confirm/' . $code)); ?></a></td></tr>  
        <tr><td>&nbsp;<br></td></tr>
        <tr><td>Thanks & Regards,</td></tr>
        <tr><td>&nbsp;</td></tr>
        <tr><td>Revira - Multi-vendor E-commerce Website</td></tr>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\revira\resources\views/emails/vendor_confirmation.blade.php ENDPATH**/ ?>