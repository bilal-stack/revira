    
    <?php $__env->startSection('content'); ?>
        <div class="section-box">
            <div class="breadcrumbs-div">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a class="font-xs color-gray-1000" href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><a class="font-xs color-gray-500" href="<?php echo e(url('shop')); ?>">Shop</a></li>
                        <li><a class="font-xs color-gray-500" href="<?php echo e(url('wishlist')); ?>">Wishlist</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <section class="section-box shop-template">
            <div class="container">
                <div class="box-wishlist">
                    <div class="head-wishlist">
                        <div class="item-wishlist">



                            <div class="wishlist-product"><span class="font-md-bold color-brand-3">Product</span></div>
                            <div class="wishlist-price"><span class="font-md-bold color-brand-3">Price</span></div>
                            <div class="wishlist-action"><span class="font-md-bold color-brand-3">Action</span></div>
                            <div class="wishlist-remove"><span class="font-md-bold color-brand-3">Remove</span></div>
                        </div>
                    </div>
                    <div class="content-wishlist">
                        <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $product_image_path = 'front/images/product_images/small/' . $wishlist->item->product_image;
                            ?>
                            <div class="item-wishlist">
                                
                                
                                
                                <div class="wishlist-product">
                                    <div class="product-wishlist">
                                        <div class="product-image">
                                            <a href="<?php echo e(url('product/' . $wishlist->item->id)); ?>">
                                                <?php if(!empty($wishlist->item->product_image) && file_exists($product_image_path)): ?> 
                                                    <img src="<?php echo e(asset($product_image_path)); ?>" alt="Product">
                                                <?php else: ?> 
                                                    <img src="<?php echo e(asset('front/images/product_images/small/no-image.png')); ?>" alt="Product">
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                        <div class="product-info"><a href="<?php echo e(url('wishlist/'. $wishlist->item->id)); ?>">
                                                <h6 class="color-brand-3"><?php echo e($wishlist->item->product_name); ?></h6>
                                            </a>
                                            <div class="rating">
                                                <?php
                                                    $avg = round($wishlist->item->ratings_avg_rating, 1); // average like 4.2
                                                    $fullStars = floor($avg); // e.g. 4
                                                    $halfStar = ($avg - $fullStars) >= 0.5;
                                                    $emptyStars = 5 - $fullStars - ($halfStar ? 1 : 0);
                                                ?>

                                                
                                                <?php for($i = 0; $i < $fullStars; $i++): ?>
                                                    <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star.svg')); ?>" alt="Revira">
                                                <?php endfor; ?>

                                                
                                                <?php if($halfStar): ?>
                                                    <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star-gray.svg')); ?>" alt="Revira">
                                                <?php endif; ?>
                                                
                                                <?php for($i = 0; $i < $emptyStars; $i++): ?>
                                                    <img src="<?php echo e(asset('front/new/assets/imgs/template/icons/star-gray.svg')); ?>" alt="Revira">
                                                <?php endfor; ?>

                                                <span class="font-xs color-gray-500">(<?php echo e(number_format($avg, 1)); ?>/5) <?php echo e($wishlist->item->ratings_count); ?> reviews</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wishlist-price">
                                    <?php
                                        $currency = session('currency', 'GBP');
                                        $price = currency($wishlist->item->product_price, $from = null, $currency);
                                        $getDiscountPrice = \App\Models\Product::getDiscountPrice($wishlist->item->id);
                                    ?>

                                    <?php if($getDiscountPrice > 0): ?> 
                                    <?php ($discountPrice = currency($getDiscountPrice, $from = null, $currency)); ?>
                                
                                    <strong class="font-lg-bold color-brand-3 price-main"><?php echo e($discountPrice); ?></strong>
                                    <span class="color-gray-500 price-line"><?php echo e($price); ?></span>

                                    <?php else: ?> 
                                    <strong class="font-lg-bold color-brand-3 price-main"><?php echo e($price); ?></strong>
                                    <?php endif; ?>
                                </div>
                                <div class="wishlist-action">
                                    <a class="btn btn-cart font-sm-bold" href="<?php echo e(url('product/' . $wishlist->item->id)); ?>">Add to Cart</a>
                                </div>
                                <div class="wishlist-remove"><a class="btn btn-delete" href="<?php echo e(url('wishlist/remove/'. $wishlist->id)); ?>"></a></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
































































































































































































































































            </div>
        </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/front/wishlist.blade.php ENDPATH**/ ?>