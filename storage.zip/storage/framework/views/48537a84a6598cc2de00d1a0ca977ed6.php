


<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-md-12 grid-margin">
                    <div class="row">
                        <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                            <h3 class="font-weight-bold">Update Vendor Details</h3>

                        </div>

                    </div>
                </div>
            </div>



            <?php if($slug == 'personal'): ?> 
                <div class="row">
                    <div class="col-md-6 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Update Personal Information</h4>


                                
                                
                                <?php if(Session::has('error_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>



                                
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>



                                
                                
                                <?php if(Session::has('success_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>



                                <form class="forms-sample" action="<?php echo e(url('admin/update-vendor-details/personal')); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <!-- Using the enctype="multipart/form-data" to allow uploading files (images) -->
                                    <div class="form-group">
                                        <label>Vendor Username/Email</label>
                                        <input class="form-control" value="<?php echo e(Auth::guard('admin')->user()->email); ?>" readonly> <!-- Check updateAdminPassword() method in AdminController.php --> 
                                    </div>
                                    <div class="form-group">
                                        <label for="vendor_name">Name</label>
                                        <input type="text" class="form-control" id="vendor_name" placeholder="Enter Name" name="vendor_name" value="<?php echo e(Auth::guard('admin')->user()->name); ?>">  
                                    </div>
                                    <div class="form-group">
                                        <label for="vendor_address">Address</label>
                                        <input type="text" class="form-control" id="vendor_address" placeholder="Enter Address" name="vendor_address" value="<?php echo e($vendorDetails['address']); ?>"> 
                                    </div>
                                    <div class="form-group">
                                        <label for="vendor_city">City</label>
                                        <input type="text" class="form-control" id="vendor_city" placeholder="Enter City" name="vendor_city" value="<?php echo e($vendorDetails['city']); ?>"> 
                                    </div>
                                    <div class="form-group">
                                        <label for="vendor_state">State</label>
                                        <input type="text" class="form-control" id="vendor_state" placeholder="Enter State" name="vendor_state" value="<?php echo e($vendorDetails['state']); ?>"> 
                                    </div>
                                    <div class="form-group">
                                        
                                        <label for="shop_country">Country</label>

                                        <select class="form-control" id="vendor_country" name="vendor_country"  style="color: #495057">
                                            <option value="">Select Country</option>

                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <option value="<?php echo e($country['country_name']); ?>" <?php if($country['country_name'] == $vendorDetails['country']): ?> selected <?php endif; ?>><?php echo e($country['country_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="vendor_pincode">Pincode</label>
                                        <input type="text" class="form-control" id="vendor_pincode" placeholder="Enter Pincode" name="vendor_pincode" value="<?php echo e($vendorDetails['pincode']); ?>"> 
                                    </div>
                                    <div class="form-group">
                                        <label for="vendor_mobile">Mobile</label>
                                        <input type="text" class="form-control" id="vendor_mobile" placeholder="Enter 10 Digit Mobile Number" name="vendor_mobile" value="<?php echo e(Auth::guard('admin')->user()->mobile); ?>" maxlength="10" minlength="10"> 
                                    </div>
                                    <div class="form-group">
                                        <label for="vendor_image">Vendor Photo</label>
                                        <input type="file" class="form-control" id="vendor_image" name="vendor_image">
                                        
                                        <?php if(!empty(Auth::guard('admin')->user()->image)): ?> 
                                            <a target="_blank" href="<?php echo e(url('admin/images/photos/' . Auth::guard('admin')->user()->image)); ?>">View Image</a> <!-- We used    target="_blank"    to open the image in another separate page --> 
                                            <input type="hidden" name="current_vendor_image" value="<?php echo e(Auth::guard('admin')->user()->image); ?>"> <!-- to send the current admin image url all the time with all the requests --> 
                                        <?php endif; ?>
                                    </div>
                                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                    <button type="reset"  class="btn btn-light">Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif($slug == 'business'): ?>
                <div class="row">
                    <div class="col-md-6 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Update Vendor Business Information</h4>


                                
                                
                                <?php if(Session::has('error_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>



                                
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>



                                

                                
                                <?php if(Session::has('success_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>



                                <form class="forms-sample" action="<?php echo e(url('admin/update-vendor-details/business')); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <!-- Using the enctype="multipart/form-data" to allow uploading files (images) -->
                                    <div class="form-group">
                                        <label>Vendor Username/Email</label>
                                        <input class="form-control" value="<?php echo e(Auth::guard('admin')->user()->email); ?>" readonly> <!-- Check updateAdminPassword() method in AdminController.php --> 
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_name">Shop Name</label>
                                        <input type="text" class="form-control" id="shop_name" placeholder="Enter Shop Name" name="shop_name"  <?php if(isset($vendorDetails['shop_name'])): ?> value="<?php echo e($vendorDetails['shop_name']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_address">Shop Address</label>
                                        <input type="text" class="form-control" id="shop_address" placeholder="Enter Shop Address" name="shop_address"  <?php if(isset($vendorDetails['shop_address'])): ?> value="<?php echo e($vendorDetails['shop_address']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_city">Shop City</label>
                                        <input type="text" class="form-control" id="shop_city" placeholder="Enter Shop City" name="shop_city"  <?php if(isset($vendorDetails['shop_city'])): ?> value="<?php echo e($vendorDetails['shop_city']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_state">Shop State</label>
                                        <input type="text" class="form-control" id="shop_state" placeholder="Enter Shop State" name="shop_state"  <?php if(isset($vendorDetails['shop_state'])): ?> value="<?php echo e($vendorDetails['shop_state']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        
                                        <label for="shop_country">Shop Country</label>

                                        <select class="form-control" id="shop_country" name="shop_country" style="color: #495057">
                                            <option value="">Select Country</option>

                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <option value="<?php echo e($country['country_name']); ?>"  <?php if(isset($vendorDetails['shop_country']) && $country['country_name'] == $vendorDetails['shop_country']): ?> selected <?php endif; ?>><?php echo e($country['country_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_pincode">Shop Pincode</label>
                                        <input type="text" class="form-control" id="shop_pincode" placeholder="Enter Shop Pincode" name="shop_pincode"  <?php if(isset($vendorDetails['shop_pincode'])): ?> value="<?php echo e($vendorDetails['shop_pincode']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_mobile">Shop Mobile</label>
                                        <input type="text" class="form-control" id="shop_mobile" placeholder="Enter 10 Digit Shop Mobile Number" name="shop_mobile"  <?php if(isset($vendorDetails['shop_mobile'])): ?> value="<?php echo e($vendorDetails['shop_mobile']); ?>" <?php endif; ?> maxlength="10" minlength="10">
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_mobile">Shop Website</label>
                                        <input type="text" class="form-control" id="shop_website" placeholder="Enter Shop Website" name="shop_website"  <?php if(isset($vendorDetails['shop_website'])): ?> value="<?php echo e($vendorDetails['shop_website']); ?>" <?php endif; ?>>
                                    </div>
                                    <div class="form-group">
                                        <label for="business_license_number">Business License Number</label>
                                        <input type="text" class="form-control" id="business_license_number" placeholder="Enter Business License Number" name="business_license_number"  <?php if(isset($vendorDetails['business_license_number'])): ?> value="<?php echo e($vendorDetails['business_license_number']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="gst_number">GST Number</label>
                                        <input type="text" class="form-control" id="gst_number" placeholder="Enter GST Number" name="gst_number"  <?php if(isset($vendorDetails['gst_number'])): ?> value="<?php echo e($vendorDetails['gst_number']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="pan_number">PAN Number</label>
                                        <input type="text" class="form-control" id="pan_number" placeholder="Enter PAN Number" name="pan_number"  <?php if(isset($vendorDetails['pan_number'])): ?> value="<?php echo e($vendorDetails['pan_number']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="address_proof">Shop Address Proof</label>
                                        <select class="form-control" name="address_proof" id="address_proof">
                                            <option value="Passport"        <?php if(isset($vendorDetails['address_proof']) && $vendorDetails['address_proof'] == 'Passport'): ?>        selected <?php endif; ?>>Passport</option>
                                            <option value="Voting Card"     <?php if(isset($vendorDetails['address_proof']) && $vendorDetails['address_proof'] == 'Voting Card'): ?>     selected <?php endif; ?>>Voting Card</option>
                                            <option value="PAN"             <?php if(isset($vendorDetails['address_proof']) && $vendorDetails['address_proof'] == 'PAN'): ?>             selected <?php endif; ?>>PAN</option>
                                            <option value="Driving License" <?php if(isset($vendorDetails['address_proof']) && $vendorDetails['address_proof'] == 'Driving License'): ?> selected <?php endif; ?>>Driving License</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="shop_image">Shop Image</label>
                                        <input type="file" class="form-control" id="shop_image" name="shop_image">
                                        
                                        <?php if(!empty($vendorDetails['shop_image'])): ?>
                                            <a target="_blank" href="<?php echo e(url('admin/images/photos/' . $vendorDetails['shop_image'])); ?>">View Image</a> <!-- We used    target="_blank"    to open the image in another separate page -->
                                            <input type="hidden" name="current_address_proof" value="<?php echo e($vendorDetails['shop_image']); ?>"> <!-- to send the current admin image url all the time with all the requests -->
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="address_proof_image">Address Proof Image</label>
                                        <input type="file" class="form-control" id="address_proof_image" name="address_proof_image">
                                        
                                        <?php if(!empty($vendorDetails['address_proof_image'])): ?>
                                            <a target="_blank" href="<?php echo e(url('admin/images/proofs/' . $vendorDetails['address_proof_image'])); ?>">View Image</a> <!-- We used    target="_blank"    to open the image in another separate page -->
                                            <input type="hidden" name="current_address_proof" value="<?php echo e($vendorDetails['address_proof_image']); ?>"> <!-- to send the current admin image url all the time with all the requests -->
                                        <?php endif; ?>
                                    </div>
                                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                    <button type="reset"  class="btn btn-light">Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif($slug == 'bank'): ?>
                <div class="row">
                    <div class="col-md-6 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Update Vendor Bank Information</h4>


                                
                                
                                <?php if(Session::has('error_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>



                                
                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">


                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>



                                
                                
                                <?php if(Session::has('success_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>



                                <form class="forms-sample" action="<?php echo e(url('admin/update-vendor-details/bank')); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <!-- Using the enctype="multipart/form-data" to allow uploading files (images) -->
                                    <div class="form-group">
                                        <label>Vendor Username/Email</label>
                                        <input class="form-control" value="<?php echo e(Auth::guard('admin')->user()->email); ?>" readonly> <!-- Check updateAdminPassword() method in AdminController.php --> 
                                    </div>
                                    <div class="form-group">
                                        <label for="account_holder_name">Account Holder Name</label>
                                        <input type="text" class="form-control" id="account_holder_name" placeholder="Enter Account Holder Name" name="account_holder_name"  <?php if(isset($vendorDetails['account_holder_name'])): ?> value="<?php echo e($vendorDetails['account_holder_name']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="bank_name">Bank Name</label>
                                        <input type="text" class="form-control" id="bank_name" placeholder="Enter Bank Name" name="bank_name"  <?php if(isset($vendorDetails['bank_name'])): ?> value="<?php echo e($vendorDetails['bank_name']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="account_number">Account Number</label>
                                        <input type="text" class="form-control" id="account_number" placeholder="Enter Account Number" name="account_number"  <?php if(isset($vendorDetails['account_number'])): ?> value="<?php echo e($vendorDetails['account_number']); ?>" <?php endif; ?>> 
                                    </div>
                                    <div class="form-group">
                                        <label for="bank_ifsc_code">Bank IFSC Code</label>
                                        <input type="text" class="form-control" id="bank_ifsc_code" placeholder="Enter Bank IFSC Code" name="bank_ifsc_code"  <?php if(isset($vendorDetails['bank_ifsc_code'])): ?> value="<?php echo e($vendorDetails['bank_ifsc_code']); ?>" <?php endif; ?>> 
                                    </div>
                                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                    <button type="reset"  class="btn btn-light">Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>



        </div>
        <!-- content-wrapper ends -->
        <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/admin/settings/update_vendor_details.blade.php ENDPATH**/ ?>