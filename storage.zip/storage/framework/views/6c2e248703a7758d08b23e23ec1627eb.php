
<?php $__env->startSection('content'); ?>
    <div class="section-box">
        <div class="breadcrumbs-div">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a class="font-xs color-gray-1000" href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a class="font-xs color-gray-500" href="<?php echo e(url('shop')); ?>">Shop</a></li>
                    <li><a class="font-xs color-gray-500" href="#">Cart</a></li>
                </ul>
            </div>
        </div>
    </div>
    <section class="section-box shop-template">
        <div class="container">
            <div id="appendCartItems"> 
                <?php echo $__env->make('front.products.cart_items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


            <div class="row">
                
                <div class="col-lg-12">
                    <div class="row mb-50">
                    <div class="col-lg-6 col-md-6">
                        <div class="box-cart-left">
                            <h5 class="font-md-bold mb-10">Calculate Shipping</h5>
                            <span class="font-sm-bold mb-5 d-inline-block color-gray-500">Flat rate:</span>
                            <span class="font-sm-bold d-inline-block color-brand-3">5%</span>
                            <div class="form-group">
                                <select class="form-control select-style1 color-gray-700"
                                        name="shipping_country">
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ship->id); ?>"><?php echo e($ship->country); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>










                        </div>
                    </div>


                    <div class="col-lg-6 col-md-6">
                        <div class="box-cart-right p-20">
                            <h5 class="font-md-bold mb-10">Apply Coupon</h5>
                            <span class="font-sm-bold mb-5 d-inline-block color-gray-500">Using A Promo
                                                Code?</span>
                            <div class="form-group d-flex">
                                <form id="applyCoupon" method="post" action="javascript:void(0)" style="display:flex"
                                      <?php if(\Illuminate\Support\Facades\Auth::check()): ?> user=1 <?php endif; ?>>
                                    <input type="text" required class="form-control mr-15" placeholder="Enter Your Coupon" id="code" name="code" value="<?php echo e(session('coupon_code')); ?>">
                                    <button class="btn btn-buy w-auto" type="submit">Apply</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col-lg-12">
                    <div class="row mb-40 d-flex justify-content-between">
                        <a class="btn btn-buy w-auto arrow-back mb-10" href="<?php echo e(url('shop')); ?>">
                            Continue shopping
                        </a>

                        <a class="btn btn-buy w-auto arrow-next mb-10" href="<?php echo e(url('checkout')); ?>">
                            Proceed To Checkout
                        </a>
                    </div>
                </div>


            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/front/products/cart.blade.php ENDPATH**/ ?>