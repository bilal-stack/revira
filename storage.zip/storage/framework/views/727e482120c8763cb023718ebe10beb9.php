
<?php $__env->startSection('content'); ?>

    <section class="section-box shop-template mt-30">
        <div class="container">
            <div class="d-flex box-banner-vendor">

                <div class="vendor-left mt-55 mb-50">
                    <div class="banner-vendor">

                        <div class="d-flex box-info-vendor">
                            <div class="avarta">
                                <?php if(!empty($vendor->vendorbusinessdetails->shop_image)): ?>
                                    <img class="mb-5" src="<?php echo e(url('admin/images/photos/' . $vendor->vendorbusinessdetails->shop_image)); ?>" alt="<?php echo e($vendor->vendorbusinessdetails->shop_name); ?>">
                                <?php else: ?>
                                    <img class="mb-5" src="<?php echo e(asset('front/images/store-default.png')); ?>" alt="<?php echo e($vendor->vendorbusinessdetails->shop_name); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="info-vendor">
                                <h4 class="mb-5"><?php echo e($vendor->vendorbusinessdetails->shop_name); ?></h4>
                                <span class="font-xs color-gray-500 mr-20">Member since <?php echo e(\Carbon\Carbon::parse($vendor->created_at)->format('F Y')); ?></span>
                                <div class="col-xl-7 col-lg-12">
                                    <div class="d-inline-block font-md color-gray-500 location mb-10"><?php echo e($vendor->vendorbusinessdetails->shop_country); ?></div>
                                </div>
                            </div>
                            <div class="vendor-contact">
                                <div class="row">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-bottom mb-20 border-vendor"></div>

            <div class="section-box shop-template mt-30">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-9 order-first order-lg-last">
                            <div class="box-filters mt-0 pb-5 border-bottom">
                                <div class="row">
                                    <div class="col-xl-2 col-lg-3 mb-10 text-lg-start text-center">
                                    </div>
                                    <div class="col-xl-10 col-lg-9 mb-10 text-lg-end text-center">
                                <span class="font-sm color-gray-900 font-medium border-1-right span">
                                    Showing: <?php echo e(count($categoryProducts)); ?>

                                </span>

                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        

                                        <div class="d-inline-block">
                                            <form name="sortProducts" id="sortProducts">
                                                <input type="hidden" name="url" id="url" value="<?php echo e($vendor->shop_name); ?>">
                                                <span class="font-sm color-gray-500 font-medium">Sort by:</span>
                                                <div class="dropdown dropdown-sort">
                                                    <select name="sort" id="sort" class="form-control select-box">
                                                        
                                                        <option value="" selected>Select</option>
                                                        <option value="product_latest" <?php if(isset($_GET['sort']) && $_GET['sort'] == 'product_latest'): ?> selected <?php endif; ?>>Sort By: Latest</option>
                                                        <option value="price_lowest"   <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_lowest'): ?>   selected <?php endif; ?>>Sort By: Lowest Price</option>
                                                        <option value="price_highest"  <?php if(isset($_GET['sort']) && $_GET['sort'] == 'price_highest'): ?>  selected <?php endif; ?>>Sort By: Highest Price</option>
                                                        <option value="name_a_z"       <?php if(isset($_GET['sort']) && $_GET['sort'] == 'name_a_z'): ?>       selected <?php endif; ?>>Sort By: Name A - Z</option>
                                                        <option value="name_z_a"       <?php if(isset($_GET['sort']) && $_GET['sort'] == 'name_z_a'): ?>       selected <?php endif; ?>>Sort By: Name Z - A</option>
                                                    </select>
                                                </div>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="filter_products">
                                <?php echo $__env->make('front.vendors.ajax_vendor_products_listing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>

                        <div class="col-lg-3 order-last order-lg-first">
                            <?php echo $__env->make('front.vendors.filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('front.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\revira\resources\views/front/vendors/vendor_listing.blade.php ENDPATH**/ ?>