<label class="currency-label"><?php echo e(session('currency')); ?></label>
<?php /**PATH C:\xampp\htdocs\revira\resources\views/front/layout/currency.blade.php ENDPATH**/ ?>